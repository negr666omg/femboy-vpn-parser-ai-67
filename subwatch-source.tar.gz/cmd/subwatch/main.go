package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"

	"github.com/negr666omg/subwatch/internal/app"
)

const version = "0.1.0"

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}
func run(args []string) error {
	command := "run"
	if len(args) > 0 && !strings.HasPrefix(args[0], "-") {
		command = args[0]
		args = args[1:]
	}
	switch command {
	case "version":
		fmt.Printf("SubWatch %s (%s/%s)\n", version, runtime.GOOS, runtime.GOARCH)
		return nil
	case "init":
		fs := flag.NewFlagSet("init", flag.ContinueOnError)
		dir := fs.String("dir", ".", "directory where sources.txt will be created")
		if err := fs.Parse(args); err != nil {
			if errors.Is(err, flag.ErrHelp) {
				return nil
			}
			return err
		}
		if err := app.Init(*dir); err != nil {
			return err
		}
		fmt.Printf("Created %s/sources.txt\n", strings.TrimRight(*dir, "/"))
		return nil
	case "interfaces":
		if len(args) > 0 {
			return fmt.Errorf("interfaces does not accept options")
		}
		return app.Interfaces(os.Stdout)
	case "run":
		return runCommand(args)
	default:
		return fmt.Errorf("unknown command %q (use run, init, interfaces, version)", command)
	}
}
func runCommand(args []string) error {
	fs := flag.NewFlagSet("run", flag.ContinueOnError)
	sources := fs.String("sources", "sources.txt", "path to list of subscription sources")
	out := fs.String("out", "out", "output directory")
	iface := fs.String("interface", "auto", "outbound network interface: auto, wlan0, throne-tun, or another interface name")
	corePath := fs.String("core-path", "", "path to sing-box executable (auto-download if omitted and not on PATH)")
	concurrency := fs.Int("concurrency", 8, "maximum number of nodes tested at once (1-32)")
	timeout := fs.Duration("timeout", 12*time.Second, "timeout for a single network request")
	testURL := fs.String("url", "https://www.gstatic.com/generate_204", "URL used for the initial connectivity test")
	minDown := fs.Float64("min-download", 5, "minimum download rate in decimal Mbps")
	minUp := fs.Float64("min-upload", 5, "minimum upload rate in decimal Mbps")
	downBytes := fs.Int64("download-bytes", 8<<20, "download test size per successful URL test")
	upBytes := fs.Int64("upload-bytes", 4<<20, "upload test size per successful URL test")
	if err := fs.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return nil
		}
		return err
	}
	if fs.NArg() != 0 {
		return fmt.Errorf("unexpected arguments: %s", strings.Join(fs.Args(), " "))
	}
	if *minDown < 0 || *minUp < 0 {
		return fmt.Errorf("minimum speeds cannot be negative")
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	return app.Run(ctx, app.Options{Sources: *sources, OutDir: *out, Interface: *iface, CorePath: *corePath, Concurrency: *concurrency, Timeout: *timeout, URL: *testURL, DownloadBytes: *downBytes, UploadBytes: *upBytes, MinDownload: *minDown, MinUpload: *minUp}, os.Stdout, os.Stderr)
}
