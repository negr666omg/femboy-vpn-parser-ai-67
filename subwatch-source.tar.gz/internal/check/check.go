package check

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/negr666omg/subwatch/internal/sub"
)

type Settings struct {
	Timeout       time.Duration
	URL           string
	DownloadBytes int64
	UploadBytes   int64
	MinDownload   float64
	MinUpload     float64
}

func NewClient(proxyURL string, timeout time.Duration) (*http.Client, error) {
	p, err := url.Parse(proxyURL)
	if err != nil {
		return nil, err
	}
	tr := &http.Transport{Proxy: http.ProxyURL(p), MaxIdleConns: 4, MaxIdleConnsPerHost: 2, IdleConnTimeout: 30 * time.Second, DisableCompression: false}
	return &http.Client{Transport: tr, Timeout: timeout, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 5 {
			return http.ErrUseLastResponse
		}
		return nil
	}}, nil
}
func CloseClient(c *http.Client) {
	if c != nil {
		if t, ok := c.Transport.(*http.Transport); ok {
			t.CloseIdleConnections()
		}
	}
}

func URLTest(ctx context.Context, client *http.Client, target string) (bool, int64, error) {
	start := time.Now()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
	if err != nil {
		return false, 0, err
	}
	req.Header.Set("User-Agent", "SubWatch/0.1 URL check")
	resp, err := client.Do(req)
	elapsed := time.Since(start).Milliseconds()
	if err != nil {
		return false, elapsed, err
	}
	defer resp.Body.Close()
	_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<20))
	return resp.StatusCode >= 200 && resp.StatusCode < 400, elapsed, nil
}

func SpeedTest(ctx context.Context, client *http.Client, downloadBytes, uploadBytes int64) (float64, float64, error) {
	if downloadBytes < 256*1024 || uploadBytes < 64*1024 {
		return 0, 0, fmt.Errorf("test payload too small")
	}
	dreq, err := http.NewRequestWithContext(ctx, http.MethodGet, fmt.Sprintf("https://speed.cloudflare.com/__down?bytes=%d", downloadBytes), nil)
	if err != nil {
		return 0, 0, err
	}
	start := time.Now()
	resp, err := client.Do(dreq)
	if err != nil {
		return 0, 0, fmt.Errorf("download: %w", err)
	}
	n, readErr := io.Copy(io.Discard, io.LimitReader(resp.Body, downloadBytes+1))
	_ = resp.Body.Close()
	elapsed := time.Since(start).Seconds()
	if readErr != nil {
		return 0, 0, fmt.Errorf("download: %w", readErr)
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return 0, 0, fmt.Errorf("download: HTTP %d", resp.StatusCode)
	}
	if n == 0 || elapsed <= 0 {
		return 0, 0, fmt.Errorf("download: empty response")
	}
	down := float64(n) * 8 / elapsed / 1e6
	payload := bytes.Repeat([]byte{0x5a}, int(uploadBytes))
	ureq, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://speed.cloudflare.com/__up", bytes.NewReader(payload))
	if err != nil {
		return down, 0, err
	}
	ureq.Header.Set("Content-Type", "application/octet-stream")
	start = time.Now()
	uresp, err := client.Do(ureq)
	if err != nil {
		return down, 0, fmt.Errorf("upload: %w", err)
	}
	_, _ = io.Copy(io.Discard, io.LimitReader(uresp.Body, 4096))
	_ = uresp.Body.Close()
	upElapsed := time.Since(start).Seconds()
	if uresp.StatusCode < 200 || uresp.StatusCode >= 300 {
		return down, 0, fmt.Errorf("upload: HTTP %d", uresp.StatusCode)
	}
	if upElapsed <= 0 {
		return down, 0, fmt.Errorf("upload: invalid duration")
	}
	up := float64(uploadBytes) * 8 / upElapsed / 1e6
	return down, up, nil
}

var geminiTrue = regexp.MustCompile(`45631641(?:\\?":|,null,)true`)
var geminiFalse = regexp.MustCompile(`45631641(?:\\?":|,null,)false`)
var geminiRegion = regexp.MustCompile(`,2,1,200,"([A-Z]{3})"`)

func GeminiTest(ctx context.Context, client *http.Client) (status, note, region string, err error) {
	req, e := http.NewRequestWithContext(ctx, http.MethodGet, "https://gemini.google.com/app?hl=en", nil)
	if e != nil {
		return "failed", "request creation", "", e
	}
	req.Header.Set("Cookie", "SOCS=CAI")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Sec-Ch-Ua", `"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"`)
	req.Header.Set("Sec-Ch-Ua-Mobile", "?0")
	req.Header.Set("Sec-Ch-Ua-Platform", `"Windows"`)
	req.Header.Set("Sec-Fetch-Dest", "document")
	req.Header.Set("Sec-Fetch-Mode", "navigate")
	req.Header.Set("Sec-Fetch-Site", "none")
	req.Header.Set("Sec-Fetch-User", "?1")
	req.Header.Set("Upgrade-Insecure-Requests", "1")
	resp, e := client.Do(req)
	if e != nil {
		return "failed", e.Error(), "", e
	}
	defer resp.Body.Close()
	body, readErr := io.ReadAll(io.LimitReader(resp.Body, 1572864))
	if readErr != nil {
		return "failed", "response read error", "", readErr
	}
	if m := geminiRegion.FindSubmatch(body); len(m) > 1 {
		region = string(m[1])
	}
	finalURL := ""
	if resp.Request != nil && resp.Request.URL != nil {
		finalURL = resp.Request.URL.String()
	}
	status, note, classifiedRegion := ClassifyGemini(resp.StatusCode, finalURL, body)
	if region == "" {
		region = classifiedRegion
	}
	return status, note, region, nil
}

// ClassifyGemini mirrors Throne's public, signed-out page classifier. It does not
// authenticate or infer account-specific eligibility.
func ClassifyGemini(httpStatus int, finalURL string, body []byte) (status, note, region string) {
	if m := geminiRegion.FindSubmatch(body); len(m) > 1 {
		region = string(m[1])
	}
	if httpStatus >= 200 && httpStatus < 300 && strings.HasPrefix(finalURL, "https://consent.") {
		return "unknown", "Consent page", region
	}
	if httpStatus >= 200 && httpStatus < 300 && strings.HasPrefix(finalURL, "https://gemini.google.com/") {
		if geminiTrue.Match(body) {
			return "available", "", region
		}
		if geminiFalse.Match(body) {
			return "partial", "Refused when signed out; a signed-in account can still work", region
		}
		return "unknown", "No availability flag on the page", region
	}
	if httpStatus == http.StatusForbidden || httpStatus == http.StatusTooManyRequests {
		return "blocked", fmt.Sprintf("HTTP %d", httpStatus), region
	}
	return "unknown", fmt.Sprintf("Unexpected response (HTTP %d)", httpStatus), region
}

type IPDetails struct {
	IP, Country, ASN, Org, Type string
	Flags                       map[string]bool
}

func LookupIP(ctx context.Context, client *http.Client) IPDetails {
	var result IPDetails
	result.Flags = map[string]bool{}
	for _, provider := range []struct {
		name, url string
		paths     map[string]string
	}{
		{"iplocate", "https://iplocate.io/api/lookup/", map[string]string{"ip": "ip", "country": "country_code", "asn": "asn.asn", "org": "asn.name", "type": "asn.type", "vpn": "privacy.is_vpn", "proxy": "privacy.is_proxy", "tor": "privacy.is_tor", "hosting": "privacy.is_hosting"}},
		{"ipquery", "https://api.ipquery.io/?format=json", map[string]string{"ip": "ip", "country": "location.country_code", "asn": "isp.asn", "org": "isp.org", "type": "isp.type", "vpn": "risk.is_vpn", "proxy": "risk.is_proxy", "tor": "risk.is_tor", "hosting": "risk.is_datacenter"}},
	} {
		req, e := http.NewRequestWithContext(ctx, http.MethodGet, provider.url, nil)
		if e != nil {
			continue
		}
		req.Header.Set("User-Agent", "SubWatch/0.1")
		resp, e := client.Do(req)
		if e != nil {
			continue
		}
		data, _ := io.ReadAll(io.LimitReader(resp.Body, 256*1024))
		resp.Body.Close()
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			continue
		}
		var root map[string]any
		if json.Unmarshal(data, &root) != nil {
			continue
		}
		for field, path := range provider.paths {
			v := jsonPath(root, path)
			switch field {
			case "ip":
				if result.IP == "" {
					result.IP = asString(v)
				}
			case "country":
				if result.Country == "" {
					result.Country = asString(v)
				}
			case "asn":
				if result.ASN == "" {
					result.ASN = asString(v)
				}
			case "org":
				if result.Org == "" {
					result.Org = asString(v)
				}
			case "type":
				if result.Type == "" {
					result.Type = asString(v)
				}
			default:
				if b, ok := v.(bool); ok {
					result.Flags[field] = b
				}
			}
		}
	}
	return result
}
func jsonPath(root map[string]any, path string) any {
	var cur any = root
	for _, part := range strings.Split(path, ".") {
		m, ok := cur.(map[string]any)
		if !ok {
			return nil
		}
		cur = m[part]
	}
	return cur
}
func asString(v any) string {
	switch x := v.(type) {
	case string:
		return x
	case float64:
		return fmt.Sprintf("%.0f", x)
	case json.Number:
		return string(x)
	default:
		return ""
	}
}

func NodeContext(parent context.Context, timeout time.Duration) (context.Context, context.CancelFunc) {
	return context.WithTimeout(parent, timeout)
}
func ApplyIP(n *sub.Node, info IPDetails) {
	n.ExitIP = info.IP
	n.Country = info.Country
	n.ASN = info.ASN
	n.Org = info.Org
	n.IPType = info.Type
	n.IPFlags = info.Flags
}
