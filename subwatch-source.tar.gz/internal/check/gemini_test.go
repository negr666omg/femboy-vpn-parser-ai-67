package check

import "testing"

func TestClassifyGemini(t *testing.T) {
	cases := []struct {
		name, url, body, want string
		code                  int
	}{
		{"full flag", "https://gemini.google.com/app?hl=en", `x45631641":true y`, "available", 200},
		{"partial flag", "https://gemini.google.com/app?hl=en", `x45631641,null,false y`, "partial", 200},
		{"consent", "https://consent.google.com/m?continue=gemini", `45631641":true`, "unknown", 200},
		{"blocked 403", "https://gemini.google.com/app", ``, "blocked", 403},
		{"rate limited", "https://gemini.google.com/app", ``, "blocked", 429},
		{"missing flag", "https://gemini.google.com/app", `ordinary HTML`, "unknown", 200},
		{"unexpected host", "https://accounts.google.com/", `45631641":true`, "unknown", 200},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			status, _, _ := ClassifyGemini(tc.code, tc.url, []byte(tc.body))
			if status != tc.want {
				t.Fatalf("got %q, want %q", status, tc.want)
			}
		})
	}
}
