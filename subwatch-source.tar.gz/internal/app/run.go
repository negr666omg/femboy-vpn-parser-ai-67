package app

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/negr666omg/subwatch/internal/check"
	"github.com/negr666omg/subwatch/internal/core"
	"github.com/negr666omg/subwatch/internal/sub"
)

type Options struct {
	Sources       string
	OutDir        string
	Interface     string
	CorePath      string
	Concurrency   int
	Timeout       time.Duration
	URL           string
	DownloadBytes int64
	UploadBytes   int64
	MinDownload   float64
	MinUpload     float64
}

func Init(dir string) error {
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	path := filepath.Join(dir, "sources.txt")
	if _, err := os.Stat(path); err == nil {
		return fmt.Errorf("%s already exists; leaving it unchanged", path)
	} else if !errors.Is(err, os.ErrNotExist) {
		return err
	}
	body := "# One subscription URL, local file path, or single share link per line.\n# https://example.net/subscription\n# ./my-subscription.txt\n"
	return os.WriteFile(path, []byte(body), 0600)
}

func Interfaces(w io.Writer) error {
	items, err := net.Interfaces()
	if err != nil {
		return err
	}
	fmt.Fprintln(w, "NAME\tSTATE\tMTU\tADDRESSES")
	for _, it := range items {
		addrs, _ := it.Addrs()
		values := make([]string, 0, len(addrs))
		for _, a := range addrs {
			values = append(values, a.String())
		}
		state := "down"
		if it.Flags&net.FlagUp != 0 {
			state = "up"
		}
		fmt.Fprintf(w, "%s\t%s\t%d\t%s\n", it.Name, state, it.MTU, strings.Join(values, ", "))
	}
	return nil
}

func Run(ctx context.Context, opts Options, stdout, stderr io.Writer) error {
	if opts.Concurrency < 1 || opts.Concurrency > 32 {
		return fmt.Errorf("concurrency must be between 1 and 32")
	}
	if opts.Timeout <= 0 {
		return fmt.Errorf("timeout must be positive")
	}
	if opts.Interface == "" {
		opts.Interface = "auto"
	}
	if opts.Interface != "auto" {
		if _, err := net.InterfaceByName(opts.Interface); err != nil {
			return fmt.Errorf("network interface %q not found (run 'subwatch interfaces')", opts.Interface)
		}
	}
	if opts.Sources == "" {
		opts.Sources = "sources.txt"
	}
	if opts.OutDir == "" {
		opts.OutDir = "out"
	}
	if opts.URL == "" {
		opts.URL = "https://www.gstatic.com/generate_204"
	}
	if opts.DownloadBytes == 0 {
		opts.DownloadBytes = 8 << 20
	}
	if opts.UploadBytes == 0 {
		opts.UploadBytes = 4 << 20
	}
	if opts.DownloadBytes < 256*1024 || opts.UploadBytes < 64*1024 {
		return fmt.Errorf("download/upload test payload too small")
	}
	if opts.DownloadBytes > 100<<20 || opts.UploadBytes > 100<<20 {
		return fmt.Errorf("download/upload test payload cannot exceed 100 MiB")
	}
	if err := os.MkdirAll(opts.OutDir, 0700); err != nil {
		return err
	}
	if err := os.Chmod(opts.OutDir, 0700); err != nil {
		return err
	}
	sources, err := loadSources(ctx, opts.Sources)
	if err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Sources: %d\n", len(sources))
	var nodes []sub.Node
	invalid := 0
	sourceErrors := 0
	for i, body := range sources {
		parsed, bad, e := sub.ParseDocument(body)
		invalid += bad
		if e != nil {
			sourceErrors++
			fmt.Fprintf(stderr, "source %d: %v\n", i+1, e)
			continue
		}
		nodes = append(nodes, parsed...)
	}
	seen := make(map[string]bool)
	unique := make([]sub.Node, 0, len(nodes))
	duplicates := 0
	for _, n := range nodes {
		if seen[n.Key] {
			duplicates++
			continue
		}
		seen[n.Key] = true
		unique = append(unique, n)
	}
	if len(unique) == 0 {
		return fmt.Errorf("no supported proxy nodes found (invalid lines: %d)", invalid)
	}
	if err := writeSubscription(filepath.Join(opts.OutDir, "merged-deduped.txt"), unique); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Parsed: %d | unique: %d | duplicates: %d | invalid: %d | source errors: %d\n", len(nodes), len(unique), duplicates, invalid, sourceErrors)
	fmt.Fprintf(stdout, "Interface: %s | concurrency: %d | timeout: %s\n", opts.Interface, opts.Concurrency, opts.Timeout)
	corePath, err := core.FindOrDownload(opts.CorePath)
	if err != nil {
		return fmt.Errorf("sing-box: %w", err)
	}
	opts.CorePath = corePath
	fmt.Fprintf(stdout, "sing-box: %s\n", corePath)
	results := make([]sub.Node, len(unique))
	sem := make(chan struct{}, opts.Concurrency)
	var wg sync.WaitGroup
	var printMu sync.Mutex
	for i, node := range unique {
		wg.Add(1)
		go func(i int, node sub.Node) {
			defer wg.Done()
			select {
			case sem <- struct{}{}:
			case <-ctx.Done():
				node.Err = ctx.Err().Error()
				results[i] = node
				return
			}
			defer func() { <-sem }()
			testNode(ctx, &node, opts)
			results[i] = node
			printMu.Lock()
			fmt.Fprintf(stdout, "[%d/%d] %-28s URL:%-4t DL:%6.2f Mbps UL:%6.2f Mbps Gemini:%s %s\n", i+1, len(unique), truncate(node.Name, 28), node.URLPassed, node.DownloadMbps, node.UploadMbps, emptyDash(node.GeminiStatus), truncate(node.Err, 60))
			printMu.Unlock()
		}(i, node)
	}
	wg.Wait()
	var speedPassed, geminiFull []sub.Node
	for _, n := range results {
		if n.URLPassed && n.DownloadMbps >= opts.MinDownload && n.UploadMbps >= opts.MinUpload {
			speedPassed = append(speedPassed, n)
			if n.GeminiStatus == "available" {
				geminiFull = append(geminiFull, n)
			}
		}
	}
	if err := writeSubscription(filepath.Join(opts.OutDir, "speed-passed.txt"), speedPassed); err != nil {
		return err
	}
	if err := writeSubscription(filepath.Join(opts.OutDir, "gemini-full.txt"), geminiFull); err != nil {
		return err
	}
	if err := writeReport(filepath.Join(opts.OutDir, "report.csv"), results); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "\nFinished. URL + speed passed: %d/%d | Gemini available: %d/%d\n", len(speedPassed), len(results), len(geminiFull), len(results))
	fmt.Fprintf(stdout, "Output: %s/{merged-deduped.txt,speed-passed.txt,gemini-full.txt,report.csv}\n", opts.OutDir)
	return nil
}

func loadSources(ctx context.Context, path string) ([][]byte, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read %s: %w", path, err)
	}
	if len(data) > 2<<20 {
		return nil, fmt.Errorf("%s exceeds 2 MiB", path)
	}
	var sources [][]byte
	for lineNo, line := range strings.Split(string(data), "\n") {
		entry := strings.TrimSpace(strings.TrimPrefix(line, "\ufeff"))
		if entry == "" || strings.HasPrefix(entry, "#") {
			continue
		}
		if strings.HasPrefix(entry, "http://") || strings.HasPrefix(entry, "https://") {
			u, e := url.Parse(entry)
			if e != nil || u.Host == "" {
				return nil, fmt.Errorf("%s:%d invalid URL", path, lineNo+1)
			}
			req, e := http.NewRequestWithContext(ctx, http.MethodGet, entry, nil)
			if e != nil {
				return nil, e
			}
			req.Header.Set("User-Agent", "SubWatch/0.1")
			resp, e := (&http.Client{Timeout: 30 * time.Second}).Do(req)
			if e != nil {
				return nil, fmt.Errorf("source %d download: %w", lineNo+1, e)
			}
			body, e := io.ReadAll(io.LimitReader(resp.Body, (8<<20)+1))
			resp.Body.Close()
			if e != nil {
				return nil, e
			}
			if len(body) > 8<<20 {
				return nil, fmt.Errorf("source %d exceeds 8 MiB", lineNo+1)
			}
			if resp.StatusCode < 200 || resp.StatusCode >= 300 {
				return nil, fmt.Errorf("source %d returned HTTP %d", lineNo+1, resp.StatusCode)
			}
			sources = append(sources, body)
		} else if strings.Contains(entry, "://") {
			sources = append(sources, []byte(entry))
		} else {
			local, e := os.ReadFile(entry)
			if e != nil {
				return nil, fmt.Errorf("source %d file %q: %w", lineNo+1, entry, e)
			}
			sources = append(sources, local)
		}
	}
	if len(sources) == 0 {
		return nil, fmt.Errorf("%s contains no sources", path)
	}
	return sources, nil
}

func testNode(parent context.Context, node *sub.Node, opts Options) {
	startCtx, cancel := context.WithTimeout(parent, opts.Timeout+8*time.Second)
	defer cancel()
	inst, err := core.Start(startCtx, opts.CorePath, node.Outbound, opts.Interface)
	if err != nil {
		node.Err = "start proxy: " + err.Error()
		return
	}
	defer inst.Close()
	client, err := check.NewClient(inst.ProxyURL, opts.Timeout)
	if err != nil {
		node.Err = err.Error()
		return
	}
	defer check.CloseClient(client)
	stageCtx, stageCancel := context.WithTimeout(parent, opts.Timeout)
	passed, latency, err := check.URLTest(stageCtx, client, opts.URL)
	stageCancel()
	node.LatencyMS = latency
	if err != nil {
		node.Err = "URL test: " + err.Error()
		return
	}
	node.URLPassed = passed
	if !passed {
		node.Err = "URL test returned non-success status"
		return
	}
	speedCtx, speedCancel := context.WithTimeout(parent, opts.Timeout*3)
	down, up, err := check.SpeedTest(speedCtx, client, opts.DownloadBytes, opts.UploadBytes)
	speedCancel()
	node.DownloadMbps = down
	node.UploadMbps = up
	if err != nil {
		node.Err = "speed test: " + err.Error()
		return
	}
	if down < opts.MinDownload || up < opts.MinUpload {
		node.Err = "below speed threshold"
		return
	}
	serviceCtx, serviceCancel := context.WithTimeout(parent, opts.Timeout+5*time.Second)
	status, note, region, serviceErr := check.GeminiTest(serviceCtx, client)
	if serviceErr == nil {
		lookupCtx, lookupCancel := context.WithTimeout(parent, opts.Timeout*2+5*time.Second)
		info := check.LookupIP(lookupCtx, client)
		lookupCancel()
		check.ApplyIP(node, info)
	}
	node.GeminiRegion = region
	serviceCancel()
	node.GeminiStatus = status
	node.GeminiNote = note
	if serviceErr != nil {
		node.GeminiStatus = "failed"
		node.GeminiNote = serviceErr.Error()
		node.Err = "Gemini check: " + serviceErr.Error()
	}
}

func writeSubscription(path string, nodes []sub.Node) error {
	var b strings.Builder
	for _, n := range nodes {
		b.WriteString(n.URI)
		b.WriteByte('\n')
	}
	if err := os.WriteFile(path, []byte(b.String()), 0600); err != nil {
		return err
	}
	return os.Chmod(path, 0600)
}
func writeReport(path string, nodes []sub.Node) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	w := csv.NewWriter(f)
	_ = w.Write([]string{"name", "uri", "url_passed", "latency_ms", "download_mbps", "upload_mbps", "gemini_status", "gemini_note", "gemini_region", "exit_ip", "country", "asn", "org", "ip_type", "ip_flags", "error"})
	for _, n := range nodes {
		_ = w.Write([]string{n.Name, n.URI, strconv.FormatBool(n.URLPassed), strconv.FormatInt(n.LatencyMS, 10), fmt.Sprintf("%.3f", n.DownloadMbps), fmt.Sprintf("%.3f", n.UploadMbps), n.GeminiStatus, n.GeminiNote, n.GeminiRegion, n.ExitIP, n.Country, n.ASN, n.Org, n.IPType, flagsJSON(n.IPFlags), n.Err})
	}
	w.Flush()
	if err := w.Error(); err != nil {
		return err
	}
	return f.Sync()
}
func flagsJSON(flags map[string]bool) string {
	if flags == nil {
		return "{}"
	}
	b, err := json.Marshal(flags)
	if err != nil {
		return "{}"
	}
	return string(b)
}

func truncate(s string, max int) string {
	r := []rune(s)
	if len(r) <= max {
		return s
	}
	return string(r[:max-1]) + "…"
}
func emptyDash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}
