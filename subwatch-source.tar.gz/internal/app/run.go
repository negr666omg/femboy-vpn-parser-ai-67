package app

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/negr666omg/subwatch/internal/check"
	"github.com/negr666omg/subwatch/internal/core"
	"github.com/negr666omg/subwatch/internal/sub"
)

func Init(dir string) error {
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	for name, body := range map[string]string{
		"sources.txt": "# One subscription URL, local file path, or single share link per line.\n# https://example.net/subscription\n# ./my-subscription.txt\n",
		"config.json": ExampleConfig(),
	} {
		path := filepath.Join(dir, name)
		if _, err := os.Stat(path); err == nil {
			continue
		} else if !errors.Is(err, os.ErrNotExist) {
			return err
		}
		if err := os.WriteFile(path, []byte(body), 0600); err != nil {
			return err
		}
	}
	return nil
}

func Interfaces(w io.Writer) error {
	items, err := net.Interfaces()
	if err != nil {
		return err
	}
	fmt.Fprintln(w, "NAME\tSTATE\tMTU\tADDRESSES")
	for _, it := range items {
		addrs, _ := it.Addrs()
		values := make([]string, 0, len(addrs))
		for _, a := range addrs {
			values = append(values, a.String())
		}
		state := "down"
		if it.Flags&net.FlagUp != 0 {
			state = "up"
		}
		fmt.Fprintf(w, "%s\t%s\t%d\t%s\n", it.Name, state, it.MTU, strings.Join(values, ", "))
	}
	return nil
}

func Run(ctx context.Context, opts Options, stdout, stderr io.Writer) error {
	if opts.URLConcurrency < 1 || opts.URLConcurrency > 64 {
		return fmt.Errorf("url_test.concurrency must be between 1 and 64")
	}
	if opts.SpeedConcurrency < 1 || opts.SpeedConcurrency > 64 {
		return fmt.Errorf("speed_test.concurrency must be between 1 and 64")
	}
	if opts.ServiceConcurrency < 1 || opts.ServiceConcurrency > 64 {
		return fmt.Errorf("service_check.concurrency must be between 1 and 64")
	}
	if opts.URLTimeout <= 0 || opts.SpeedTimeout <= 0 || opts.ServiceTimeout <= 0 {
		return fmt.Errorf("all stage timeouts must be positive")
	}
	if opts.MinDownload < 0 || opts.MinUpload < 0 {
		return fmt.Errorf("minimum speeds cannot be negative")
	}
	if opts.Interface == "" {
		opts.Interface = "auto"
	}
	if opts.Interface != "auto" {
		if _, err := net.InterfaceByName(opts.Interface); err != nil {
			return fmt.Errorf("network interface %q not found (run 'sw interfaces')", opts.Interface)
		}
	}
	if opts.Sources == "" {
		opts.Sources = "sources.txt"
	}
	if opts.OutDir == "" {
		opts.OutDir = "out"
	}
	if opts.URL == "" {
		opts.URL = "https://www.gstatic.com/generate_204"
	}
	if opts.DownloadBytes == 0 {
		opts.DownloadBytes = 8 << 20
	}
	if opts.UploadBytes == 0 {
		opts.UploadBytes = 4 << 20
	}
	if opts.DownloadBytes < 256*1024 || opts.UploadBytes < 64*1024 {
		return fmt.Errorf("download/upload test payload too small")
	}
	if opts.DownloadBytes > 100<<20 || opts.UploadBytes > 100<<20 {
		return fmt.Errorf("download/upload test payload cannot exceed 100 MiB")
	}
	if len(opts.Protocols) == 0 {
		opts.Protocols = DefaultOptions().Protocols
	}
	opts.Protocols = normalizeProtocols(opts.Protocols)
	if err := os.MkdirAll(opts.OutDir, 0700); err != nil {
		return err
	}
	if err := os.Chmod(opts.OutDir, 0700); err != nil {
		return err
	}

	fmt.Fprintf(stdout, "[1/4] PARSE: reading %s\n", opts.Sources)
	sources, err := loadSources(ctx, opts.Sources)
	if err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Sources loaded: %d\n", len(sources))
	metadata := collectMetadata(sources)

	var parsed []sub.Node
	invalid, sourceErrors := 0, 0
	for i, body := range sources {
		nodes, bad, parseErr := sub.ParseDocument(body)
		invalid += bad
		if parseErr != nil {
			sourceErrors++
			fmt.Fprintf(stderr, "source %d: %v\n", i+1, parseErr)
			continue
		}
		parsed = append(parsed, nodes...)
	}
	if len(parsed) == 0 {
		return fmt.Errorf("no supported proxy nodes found (invalid lines: %d)", invalid)
	}
	if err := writeJSON(filepath.Join(opts.OutDir, "all.json"), parsed); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Parsed: %d | invalid: %d | source errors: %d | metadata lines: %d\n", len(parsed), invalid, sourceErrors, len(metadata))

	// Read the parsed snapshot back before deduplication so each stage consumes its artifact.
	all, err := readJSON(filepath.Join(opts.OutDir, "all.json"))
	if err != nil {
		return fmt.Errorf("read all.json: %w", err)
	}
	unique, duplicates := deduplicate(all)
	if err := writeJSON(filepath.Join(opts.OutDir, "unique.json"), unique); err != nil {
		return err
	}
	selected := filterProtocols(unique, opts.Protocols)
	if len(selected) == 0 {
		return fmt.Errorf("no nodes match enabled protocols: %s", strings.Join(opts.Protocols, ", "))
	}
	if err := writeJSON(filepath.Join(opts.OutDir, "selected.json"), selected); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Deduplicated: %d unique | %d duplicates | selected protocols: %s | nodes to test: %d\n", len(unique), duplicates, strings.Join(opts.Protocols, ","), len(selected))
	fmt.Fprintf(stdout, "Interface: %s | URL concurrency: %d | speed concurrency: %d | service concurrency: %d\n", opts.Interface, opts.URLConcurrency, opts.SpeedConcurrency, opts.ServiceConcurrency)

	fmt.Fprintln(stdout, "[prepare] Checking sing-box; first run may download the verified core...")
	corePath, err := core.FindOrDownloadProgress(opts.CorePath, stdout)
	if err != nil {
		return fmt.Errorf("sing-box: %w", err)
	}
	opts.CorePath = corePath
	fmt.Fprintf(stdout, "[prepare] sing-box ready: %s\n", corePath)

	// Stage 1: every selected unique node gets the URL test. Nothing is speed-tested here.
	fmt.Fprintf(stdout, "\n[2/4] URL TEST: %d nodes, target %s, timeout %s\n", len(selected), opts.URL, opts.URLTimeout)
	urlResults := runStage(ctx, "URL TEST", selected, opts.URLConcurrency, stdout, func(n *sub.Node) bool { return n.URLPassed }, func(stageCtx context.Context, n *sub.Node) {
		passed, latency, testErr := runURLTest(stageCtx, *n, opts)
		n.URLPassed, n.URLLatencyMS = passed, latency
		if testErr != nil {
			n.URLError = testErr.Error()
		} else if !passed {
			n.URLError = "URL test returned non-success status"
		}
	})
	urlPassed := filterNodes(urlResults, func(n sub.Node) bool { return n.URLPassed })
	urlFailed := filterNodes(urlResults, func(n sub.Node) bool { return !n.URLPassed })
	if err := writeStageFiles(opts.OutDir, "url-test-finished", urlPassed, opts.SplitByProtocol); err != nil {
		return err
	}
	if err := writeJSON(filepath.Join(opts.OutDir, "url-test-failed.json"), urlFailed); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "URL test complete: %d passed / %d failed. Wrote url-test-finished.json\n", len(urlPassed), len(urlFailed))
	printFailureSummary(stdout, "URL failures", urlFailed, func(n sub.Node) string { return n.URLError })

	// Stage 2 reads only the completed URL-pass artifact. This is a hard global barrier.
	urlPassed, err = readJSON(filepath.Join(opts.OutDir, "url-test-finished.json"))
	if err != nil {
		return fmt.Errorf("read url-test-finished.json: %w", err)
	}
	fmt.Fprintf(stdout, "\n[3/4] SPEED TEST: %d URL-passed nodes, timeout %s, minimum DL/UL %.2f/%.2f Mbps\n", len(urlPassed), opts.SpeedTimeout, opts.MinDownload, opts.MinUpload)
	speedResults := runStage(ctx, "SPEED TEST", urlPassed, opts.SpeedConcurrency, stdout, func(n *sub.Node) bool { return n.SpeedPassed }, func(stageCtx context.Context, n *sub.Node) {
		down, up, testErr := runSpeedTest(stageCtx, *n, opts)
		n.DownloadMbps, n.UploadMbps = down, up
		if testErr != nil {
			n.SpeedError = testErr.Error()
			return
		}
		if reason := speedThresholdError(down, up, opts.MinDownload, opts.MinUpload); reason != "" {
			n.SpeedError = reason
			return
		}
		n.SpeedPassed = true
	})
	speedPassed := filterNodes(speedResults, func(n sub.Node) bool { return n.SpeedPassed })
	speedFailed := filterNodes(speedResults, func(n sub.Node) bool { return !n.SpeedPassed })
	if err := writeStageFiles(opts.OutDir, "speedtest-finished", speedPassed, opts.SplitByProtocol); err != nil {
		return err
	}
	if err := writeJSON(filepath.Join(opts.OutDir, "speedtest-failed.json"), speedFailed); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "Speed test complete: %d passed / %d failed. Wrote speedtest-finished.json\n", len(speedPassed), len(speedFailed))
	printFailureSummary(stdout, "Speed failures", speedFailed, func(n sub.Node) string { return n.SpeedError })

	// tested.json is deliberately an exact byte-for-byte copy of speedtest-finished.json.
	speedBytes, err := os.ReadFile(filepath.Join(opts.OutDir, "speedtest-finished.json"))
	if err != nil {
		return err
	}
	if err := writeAtomic(filepath.Join(opts.OutDir, "tested.json"), speedBytes); err != nil {
		return err
	}
	if opts.SplitByProtocol {
		if err := copyProtocolJSON(opts.OutDir, "speedtest-finished", "tested", speedPassed); err != nil {
			return err
		}
	}

	// Stage 3 reads only speedtest-finished.json. No service check is run on a weaker node.
	speedPassed, err = readJSON(filepath.Join(opts.OutDir, "speedtest-finished.json"))
	if err != nil {
		return fmt.Errorf("read speedtest-finished.json: %w", err)
	}
	fmt.Fprintf(stdout, "\n[4/4] SERVICE CHECK: %d speed-passed nodes, Gemini must be fully available\n", len(speedPassed))
	serviceResults := runStage(ctx, "SERVICE CHECK", speedPassed, opts.ServiceConcurrency, stdout, func(n *sub.Node) bool { return n.GeminiStatus == "available" }, func(stageCtx context.Context, n *sub.Node) {
		status, note, region, ipInfo, testErr := runServiceCheck(stageCtx, *n, opts)
		n.GeminiStatus, n.GeminiNote, n.GeminiRegion = status, note, region
		if testErr != nil {
			n.ServiceError = testErr.Error()
			n.GeminiStatus = "failed"
		}
		if opts.LookupIP && testErr == nil {
			check.ApplyIP(n, ipInfo)
		}
	})
	finalNodes := filterNodes(serviceResults, func(n sub.Node) bool { return n.GeminiStatus == "available" })
	if err := writeJSON(filepath.Join(opts.OutDir, "service-check-results.json"), serviceResults); err != nil {
		return err
	}
	if err := writeStageFiles(opts.OutDir, "final", finalNodes, opts.SplitByProtocol); err != nil {
		return err
	}
	if opts.WriteText {
		if err := writeSubscription(filepath.Join(opts.OutDir, "final.txt"), finalNodes, metadata); err != nil {
			return err
		}
		if opts.SplitByProtocol {
			if err := writeProtocolSubscriptions(opts.OutDir, "final", finalNodes, metadata); err != nil {
				return err
			}
		}
	}

	// Keep one complete CSV for diagnostics, even when a node did not pass a stage.
	allResults := mergeResults(selected, urlResults, speedResults, serviceResults)
	if err := writeReport(filepath.Join(opts.OutDir, "report.csv"), allResults); err != nil {
		return err
	}
	fmt.Fprintf(stdout, "\nFinished. Parsed: %d | unique: %d | selected: %d | URL passed: %d | speed passed: %d | Gemini available: %d\n", len(parsed), len(unique), len(selected), len(urlPassed), len(speedPassed), len(finalNodes))
	fmt.Fprintf(stdout, "Output directory: %s\n", opts.OutDir)
	fmt.Fprintln(stdout, "Files: all.json, unique.json, selected.json, url-test-finished.json, speedtest-finished.json, tested.json, final.json, service-check-results.json, report.csv")
	return ctx.Err()
}

func loadSources(ctx context.Context, path string) ([][]byte, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read %s: %w", path, err)
	}
	if len(data) > 2<<20 {
		return nil, fmt.Errorf("%s exceeds 2 MiB", path)
	}
	var sources [][]byte
	for lineNo, line := range strings.Split(string(data), "\n") {
		entry := strings.TrimSpace(strings.TrimPrefix(line, "\ufeff"))
		if entry == "" || strings.HasPrefix(entry, "#") {
			continue
		}
		if strings.HasPrefix(entry, "http://") || strings.HasPrefix(entry, "https://") {
			u, e := url.Parse(entry)
			if e != nil || u.Host == "" {
				return nil, fmt.Errorf("%s:%d invalid URL", path, lineNo+1)
			}
			req, e := http.NewRequestWithContext(ctx, http.MethodGet, entry, nil)
			if e != nil {
				return nil, e
			}
			req.Header.Set("User-Agent", "SubWatch/0.2")
			resp, e := (&http.Client{Timeout: 30 * time.Second}).Do(req)
			if e != nil {
				return nil, fmt.Errorf("source %d download: %w", lineNo+1, e)
			}
			body, e := io.ReadAll(io.LimitReader(resp.Body, (8<<20)+1))
			resp.Body.Close()
			if e != nil {
				return nil, e
			}
			if len(body) > 8<<20 {
				return nil, fmt.Errorf("source %d exceeds 8 MiB", lineNo+1)
			}
			if resp.StatusCode < 200 || resp.StatusCode >= 300 {
				return nil, fmt.Errorf("source %d returned HTTP %d", lineNo+1, resp.StatusCode)
			}
			sources = append(sources, body)
		} else if strings.Contains(entry, "://") {
			sources = append(sources, []byte(entry))
		} else {
			local, e := os.ReadFile(entry)
			if e != nil {
				return nil, fmt.Errorf("source %d file %q: %w", lineNo+1, entry, e)
			}
			sources = append(sources, local)
		}
	}
	if len(sources) == 0 {
		return nil, fmt.Errorf("%s contains no sources", path)
	}
	return sources, nil
}

func collectMetadata(sources [][]byte) []string {
	seen := map[string]bool{}
	var out []string
	for _, source := range sources {
		for _, line := range strings.Split(string(source), "\n") {
			line = strings.TrimSpace(strings.TrimPrefix(line, "\ufeff"))
			if line == "" {
				continue
			}
			keep := false
			for _, prefix := range []string{"#profile-", "#announce", "#support-url"} {
				if strings.HasPrefix(strings.ToLower(line), prefix) {
					keep = true
					break
				}
			}
			if keep && !seen[line] {
				seen[line] = true
				out = append(out, line)
			}
		}
	}
	return out
}

func deduplicate(nodes []sub.Node) ([]sub.Node, int) {
	seen := map[string]bool{}
	out := make([]sub.Node, 0, len(nodes))
	duplicates := 0
	for _, n := range nodes {
		key := n.Key
		if key == "" {
			b, _ := json.Marshal(n.Outbound)
			key = string(b)
		}
		if seen[key] {
			duplicates++
			continue
		}
		seen[key] = true
		out = append(out, n)
	}
	return out, duplicates
}

func filterProtocols(nodes []sub.Node, enabled []string) []sub.Node {
	allowed := map[string]bool{}
	for _, p := range enabled {
		allowed[p] = true
	}
	return filterNodes(nodes, func(n sub.Node) bool { return allowed[protocolOf(n)] })
}

func protocolOf(n sub.Node) string {
	if n.Protocol != "" {
		return n.Protocol
	}
	if p, ok := n.Outbound["type"].(string); ok {
		switch strings.ToLower(p) {
		case "shadowsocks":
			return "ss"
		case "hy2":
			return "hysteria2"
		case "socks5":
			return "socks"
		default:
			return strings.ToLower(p)
		}
	}
	return "unknown"
}

func filterNodes(nodes []sub.Node, keep func(sub.Node) bool) []sub.Node {
	out := make([]sub.Node, 0, len(nodes))
	for _, n := range nodes {
		if keep(n) {
			out = append(out, n)
		}
	}
	return out
}

func runStage(ctx context.Context, label string, nodes []sub.Node, concurrency int, stdout io.Writer, passed func(*sub.Node) bool, test func(context.Context, *sub.Node)) []sub.Node {
	results := make([]sub.Node, len(nodes))
	if len(nodes) == 0 {
		fmt.Fprintf(stdout, "[%s] 0/0 (nothing to test)\n", label)
		return results
	}
	if concurrency > len(nodes) {
		concurrency = len(nodes)
	}
	jobs := make(chan int)
	var workers sync.WaitGroup
	var progressMu sync.Mutex
	done, successes := 0, 0
	for worker := 0; worker < concurrency; worker++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			for i := range jobs {
				results[i] = nodes[i]
				if ctx.Err() != nil {
					setStageError(&results[i], label, ctx.Err().Error())
				} else {
					test(ctx, &results[i])
				}
				progressMu.Lock()
				done++
				if passed(&results[i]) {
					successes++
				}
				fmt.Fprintf(stdout, "\r[%s] %d/%d | passed: %d | failed: %d", label, done, len(nodes), successes, done-successes)
				progressMu.Unlock()
			}
		}()
	}
	for i := range nodes {
		jobs <- i
	}
	close(jobs)
	workers.Wait()
	fmt.Fprintln(stdout)
	return results
}

func setStageError(n *sub.Node, label, message string) {
	switch label {
	case "URL TEST":
		n.URLError = message
	case "SPEED TEST":
		n.SpeedError = message
	case "SERVICE CHECK":
		n.ServiceError = message
		n.GeminiStatus = "failed"
	}
}

func runURLTest(parent context.Context, n sub.Node, opts Options) (bool, int64, error) {
	var passed bool
	var latency int64
	err := withNodeClient(parent, n, opts, opts.URLTimeout, func(ctx context.Context, client *http.Client) error {
		testCtx, cancel := context.WithTimeout(ctx, opts.URLTimeout)
		defer cancel()
		var testErr error
		passed, latency, testErr = check.URLTest(testCtx, client, opts.URL)
		return testErr
	})
	return passed, latency, err
}

func speedThresholdError(download, upload, minDownload, minUpload float64) string {
	var reasons []string
	if download < minDownload {
		reasons = append(reasons, fmt.Sprintf("download %.2f < %.2f Mbps", download, minDownload))
	}
	if upload < minUpload {
		reasons = append(reasons, fmt.Sprintf("upload %.2f < %.2f Mbps", upload, minUpload))
	}
	return strings.Join(reasons, "; ")
}

func runSpeedTest(parent context.Context, n sub.Node, opts Options) (float64, float64, error) {
	var down, up float64
	err := withNodeClient(parent, n, opts, opts.SpeedTimeout, func(ctx context.Context, client *http.Client) error {
		testCtx, cancel := context.WithTimeout(ctx, opts.SpeedTimeout)
		defer cancel()
		var testErr error
		down, up, testErr = check.SpeedTest(testCtx, client, opts.DownloadBytes, opts.UploadBytes)
		return testErr
	})
	return down, up, err
}

func runServiceCheck(parent context.Context, n sub.Node, opts Options) (string, string, string, check.IPDetails, error) {
	var status, note, region string
	var info check.IPDetails
	err := withNodeClient(parent, n, opts, opts.ServiceTimeout, func(ctx context.Context, client *http.Client) error {
		serviceCtx, cancel := context.WithTimeout(ctx, opts.ServiceTimeout)
		defer cancel()
		var serviceErr error
		status, note, region, serviceErr = check.GeminiTest(serviceCtx, client)
		if serviceErr != nil {
			return serviceErr
		}
		if opts.LookupIP {
			lookupCtx, lookupCancel := context.WithTimeout(ctx, opts.ServiceTimeout)
			defer lookupCancel()
			info = check.LookupIP(lookupCtx, client)
		}
		return nil
	})
	return status, note, region, info, err
}

func withNodeClient(parent context.Context, n sub.Node, opts Options, timeout time.Duration, fn func(context.Context, *http.Client) error) error {
	startCtx, cancel := context.WithTimeout(parent, timeout+8*time.Second)
	defer cancel()
	inst, err := core.Start(startCtx, opts.CorePath, n.Outbound, opts.Interface)
	if err != nil {
		return fmt.Errorf("start proxy: %w", err)
	}
	defer inst.Close()
	client, err := check.NewClient(inst.ProxyURL, timeout)
	if err != nil {
		return err
	}
	defer check.CloseClient(client)
	return fn(startCtx, client)
}

func writeStageFiles(dir, base string, nodes []sub.Node, split bool) error {
	if err := writeJSON(filepath.Join(dir, base+".json"), nodes); err != nil {
		return err
	}
	if split {
		return writeProtocolJSON(dir, base, nodes)
	}
	return nil
}

func writeProtocolJSON(dir, base string, nodes []sub.Node) error {
	groups := groupProtocols(nodes)
	for protocol, group := range groups {
		if err := writeJSON(filepath.Join(dir, base+"-"+protocol+".json"), group); err != nil {
			return err
		}
	}
	return nil
}

func copyProtocolJSON(dir, sourceBase, targetBase string, nodes []sub.Node) error {
	groups := groupProtocols(nodes)
	for protocol := range groups {
		data, err := os.ReadFile(filepath.Join(dir, sourceBase+"-"+protocol+".json"))
		if err != nil {
			return err
		}
		if err := writeAtomic(filepath.Join(dir, targetBase+"-"+protocol+".json"), data); err != nil {
			return err
		}
	}
	return nil
}

func groupProtocols(nodes []sub.Node) map[string][]sub.Node {
	groups := map[string][]sub.Node{}
	for _, n := range nodes {
		p := protocolOf(n)
		if p == "" {
			p = "unknown"
		}
		groups[p] = append(groups[p], n)
	}
	return groups
}

func writeProtocolSubscriptions(dir, base string, nodes []sub.Node, metadata []string) error {
	for protocol, group := range groupProtocols(nodes) {
		if err := writeSubscription(filepath.Join(dir, base+"-"+protocol+".txt"), group, metadata); err != nil {
			return err
		}
	}
	return nil
}

func readJSON(path string) ([]sub.Node, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var nodes []sub.Node
	if err := json.Unmarshal(data, &nodes); err != nil {
		return nil, err
	}
	if nodes == nil {
		nodes = []sub.Node{}
	}
	return nodes, nil
}

func writeJSON(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	return writeAtomic(path, data)
}

func writeAtomic(path string, data []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".subwatch-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	ok := false
	defer func() {
		tmp.Close()
		if !ok {
			os.Remove(tmpName)
		}
	}()
	if err := tmp.Chmod(0600); err != nil {
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		return err
	}
	if err := tmp.Sync(); err != nil {
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmpName, path); err != nil {
		return err
	}
	ok = true
	return nil
}

func writeSubscription(path string, nodes []sub.Node, metadata []string) error {
	var b strings.Builder
	for _, line := range metadata {
		b.WriteString(line)
		b.WriteByte('\n')
	}
	if len(metadata) > 0 && len(nodes) > 0 {
		b.WriteByte('\n')
	}
	for _, n := range nodes {
		b.WriteString(n.URI)
		b.WriteByte('\n')
	}
	return writeAtomic(path, []byte(b.String()))
}

func writeReport(path string, nodes []sub.Node) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	w := csv.NewWriter(f)
	_ = w.Write([]string{"name", "protocol", "uri", "url_passed", "url_latency_ms", "url_error", "speed_passed", "download_mbps", "upload_mbps", "speed_error", "gemini_status", "gemini_note", "gemini_region", "service_error", "exit_ip", "country", "asn", "org", "ip_type", "ip_flags"})
	for _, n := range nodes {
		_ = w.Write([]string{n.Name, protocolOf(n), n.URI, strconv.FormatBool(n.URLPassed), strconv.FormatInt(n.URLLatencyMS, 10), n.URLError, strconv.FormatBool(n.SpeedPassed), fmt.Sprintf("%.3f", n.DownloadMbps), fmt.Sprintf("%.3f", n.UploadMbps), n.SpeedError, n.GeminiStatus, n.GeminiNote, n.GeminiRegion, n.ServiceError, n.ExitIP, n.Country, n.ASN, n.Org, n.IPType, flagsJSON(n.IPFlags)})
	}
	w.Flush()
	if err := w.Error(); err != nil {
		return err
	}
	return f.Sync()
}

func mergeResults(selected, urlResults, speedResults, serviceResults []sub.Node) []sub.Node {
	byURI := make(map[string]sub.Node, len(selected))
	for _, n := range selected {
		byURI[n.URI] = n
	}
	for _, group := range [][]sub.Node{urlResults, speedResults, serviceResults} {
		for _, n := range group {
			byURI[n.URI] = n
		}
	}
	out := make([]sub.Node, 0, len(selected))
	for _, n := range selected {
		if updated, ok := byURI[n.URI]; ok {
			out = append(out, updated)
		}
	}
	return out
}

func printFailureSummary(w io.Writer, title string, nodes []sub.Node, reason func(sub.Node) string) {
	if len(nodes) == 0 {
		return
	}
	counts := map[string]int{}
	for _, n := range nodes {
		r := strings.TrimSpace(reason(n))
		if r == "" {
			r = "unknown error"
		}
		counts[r]++
	}
	type item struct {
		reason string
		count  int
	}
	items := make([]item, 0, len(counts))
	for r, c := range counts {
		items = append(items, item{r, c})
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].count == items[j].count {
			return items[i].reason < items[j].reason
		}
		return items[i].count > items[j].count
	})
	fmt.Fprintf(w, "%s:\n", title)
	for i, it := range items {
		if i == 5 {
			fmt.Fprintf(w, "  ... and %d other reason(s)\n", len(items)-i)
			break
		}
		fmt.Fprintf(w, "  %dx %s\n", it.count, truncate(it.reason, 140))
	}
}

func flagsJSON(flags map[string]bool) string {
	if flags == nil {
		return "{}"
	}
	b, err := json.Marshal(flags)
	if err != nil {
		return "{}"
	}
	return string(b)
}
func truncate(s string, max int) string {
	r := []rune(s)
	if len(r) <= max {
		return s
	}
	return string(r[:max-1]) + "…"
}
