package app

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"
)

type Options struct {
	Sources            string
	OutDir             string
	Interface          string
	CorePath           string
	Protocols          []string
	URLConcurrency     int
	SpeedConcurrency   int
	ServiceConcurrency int
	URLTimeout         time.Duration
	SpeedTimeout       time.Duration
	ServiceTimeout     time.Duration
	URL                string
	DownloadBytes      int64
	UploadBytes        int64
	MinDownload        float64
	MinUpload          float64
	SplitByProtocol    bool
	WriteText          bool
	LookupIP           bool
}

type fileConfig struct {
	Network struct {
		Interface string `json:"interface"`
	} `json:"network"`
	Sources struct {
		File string `json:"file"`
	} `json:"sources"`
	Protocols struct {
		Enabled []string `json:"enabled"`
	} `json:"protocols"`
	URLTest struct {
		URL         string `json:"url"`
		Concurrency int    `json:"concurrency"`
		Timeout     string `json:"timeout"`
	} `json:"url_test"`
	SpeedTest struct {
		Concurrency   int      `json:"concurrency"`
		Timeout       string   `json:"timeout"`
		MinDownload   *float64 `json:"min_download_mbps"`
		MinUpload     *float64 `json:"min_upload_mbps"`
		DownloadBytes int64    `json:"download_bytes"`
		UploadBytes   int64    `json:"upload_bytes"`
	} `json:"speed_test"`
	ServiceCheck struct {
		Concurrency int    `json:"concurrency"`
		Timeout     string `json:"timeout"`
		LookupIP    *bool  `json:"lookup_ip"`
	} `json:"service_check"`
	Output struct {
		Directory        string `json:"directory"`
		SplitByProtocol  bool   `json:"split_by_protocol"`
		SubscriptionText *bool  `json:"subscription_text"`
	} `json:"output"`
}

func DefaultOptions() Options {
	return Options{
		Sources: "sources.txt", OutDir: "out", Interface: "auto",
		Protocols:      []string{"vless", "vmess", "trojan", "ss", "hysteria2", "tuic", "socks", "http"},
		URLConcurrency: 8, SpeedConcurrency: 4, ServiceConcurrency: 4,
		URLTimeout: 12 * time.Second, SpeedTimeout: 60 * time.Second, ServiceTimeout: 25 * time.Second,
		URL: "https://www.gstatic.com/generate_204", DownloadBytes: 8 << 20, UploadBytes: 4 << 20,
		MinDownload: 5, MinUpload: 5, WriteText: true,
	}
}

func LoadOptions(path string) (Options, error) {
	opts := DefaultOptions()
	if strings.TrimSpace(path) == "" {
		return opts, nil
	}
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) && path == "config.json" {
		return opts, nil
	}
	if err != nil {
		return opts, fmt.Errorf("read config %s: %w", path, err)
	}
	var cfg fileConfig
	if err := json.Unmarshal(data, &cfg); err != nil {
		return opts, fmt.Errorf("parse config %s: %w", path, err)
	}
	if cfg.Network.Interface != "" {
		opts.Interface = cfg.Network.Interface
	}
	if cfg.Sources.File != "" {
		opts.Sources = cfg.Sources.File
	}
	if len(cfg.Protocols.Enabled) > 0 {
		opts.Protocols = normalizeProtocols(cfg.Protocols.Enabled)
	}
	if cfg.URLTest.URL != "" {
		opts.URL = cfg.URLTest.URL
	}
	if cfg.URLTest.Concurrency > 0 {
		opts.URLConcurrency = cfg.URLTest.Concurrency
	}
	if cfg.URLTest.Timeout != "" {
		d, e := time.ParseDuration(cfg.URLTest.Timeout)
		if e != nil {
			return opts, fmt.Errorf("url_test.timeout: %w", e)
		}
		opts.URLTimeout = d
	}
	if cfg.SpeedTest.Concurrency > 0 {
		opts.SpeedConcurrency = cfg.SpeedTest.Concurrency
	}
	if cfg.SpeedTest.Timeout != "" {
		d, e := time.ParseDuration(cfg.SpeedTest.Timeout)
		if e != nil {
			return opts, fmt.Errorf("speed_test.timeout: %w", e)
		}
		opts.SpeedTimeout = d
	}
	if cfg.SpeedTest.MinDownload != nil {
		opts.MinDownload = *cfg.SpeedTest.MinDownload
	}
	if cfg.SpeedTest.MinUpload != nil {
		opts.MinUpload = *cfg.SpeedTest.MinUpload
	}
	if cfg.SpeedTest.DownloadBytes > 0 {
		opts.DownloadBytes = cfg.SpeedTest.DownloadBytes
	}
	if cfg.SpeedTest.UploadBytes > 0 {
		opts.UploadBytes = cfg.SpeedTest.UploadBytes
	}
	if cfg.ServiceCheck.Concurrency > 0 {
		opts.ServiceConcurrency = cfg.ServiceCheck.Concurrency
	}
	if cfg.ServiceCheck.Timeout != "" {
		d, e := time.ParseDuration(cfg.ServiceCheck.Timeout)
		if e != nil {
			return opts, fmt.Errorf("service_check.timeout: %w", e)
		}
		opts.ServiceTimeout = d
	}
	if cfg.ServiceCheck.LookupIP != nil {
		opts.LookupIP = *cfg.ServiceCheck.LookupIP
	}
	if cfg.Output.Directory != "" {
		opts.OutDir = cfg.Output.Directory
	}
	opts.SplitByProtocol = cfg.Output.SplitByProtocol
	if cfg.Output.SubscriptionText != nil {
		opts.WriteText = *cfg.Output.SubscriptionText
	}
	return opts, nil
}

func normalizeProtocols(protocols []string) []string {
	seen := map[string]bool{}
	out := make([]string, 0, len(protocols))
	for _, p := range protocols {
		p = strings.ToLower(strings.TrimSpace(p))
		if p == "shadowsocks" {
			p = "ss"
		}
		if p == "hy2" {
			p = "hysteria2"
		}
		if p == "socks5" {
			p = "socks"
		}
		if p != "" && !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	return out
}

func ExampleConfig() string {
	return `{
  "network": { "interface": "auto" },
  "sources": { "file": "sources.txt" },
  "protocols": { "enabled": ["vless", "vmess", "trojan", "ss", "hysteria2", "tuic"] },
  "url_test": {
    "url": "https://www.gstatic.com/generate_204",
    "concurrency": 8,
    "timeout": "12s"
  },
  "speed_test": {
    "concurrency": 4,
    "timeout": "60s",
    "min_download_mbps": 5,
    "min_upload_mbps": 5,
    "download_bytes": 8388608,
    "upload_bytes": 4194304
  },
  "service_check": {
    "concurrency": 4,
    "timeout": "25s",
    "lookup_ip": false
  },
  "output": {
    "directory": "out",
    "split_by_protocol": true,
    "subscription_text": true
  }
}
`
}
