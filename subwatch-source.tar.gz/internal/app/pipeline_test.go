package app

import (
	"bytes"
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"

	"github.com/negr666omg/subwatch/internal/sub"
)

func TestConfigLoadsStageSpecificSettings(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	data := `{
  "network":{"interface":"throne-tun"},
  "sources":{"file":"subs.txt"},
  "protocols":{"enabled":["vless","shadowsocks"]},
  "url_test":{"url":"https://example.com/204","concurrency":6,"timeout":"9s"},
  "speed_test":{"concurrency":3,"timeout":"45s","min_download_mbps":7,"min_upload_mbps":4},
  "service_check":{"concurrency":2,"timeout":"20s","lookup_ip":true},
  "output":{"directory":"results","split_by_protocol":true,"subscription_text":false}
}`
	if err := os.WriteFile(path, []byte(data), 0600); err != nil {
		t.Fatal(err)
	}
	opts, err := LoadOptions(path)
	if err != nil {
		t.Fatal(err)
	}
	if opts.Interface != "throne-tun" || opts.Sources != "subs.txt" || opts.OutDir != "results" {
		t.Fatalf("unexpected paths/network: %+v", opts)
	}
	if opts.URLConcurrency != 6 || opts.SpeedConcurrency != 3 || opts.ServiceConcurrency != 2 {
		t.Fatalf("unexpected concurrency: %+v", opts)
	}
	if opts.URLTimeout != 9*time.Second || opts.SpeedTimeout != 45*time.Second || opts.ServiceTimeout != 20*time.Second {
		t.Fatalf("unexpected timeouts: %+v", opts)
	}
	if len(opts.Protocols) != 2 || opts.Protocols[1] != "ss" {
		t.Fatalf("protocol aliases not normalized: %#v", opts.Protocols)
	}
	if opts.MinDownload != 7 || opts.MinUpload != 4 || !opts.LookupIP || !opts.SplitByProtocol || opts.WriteText {
		t.Fatalf("unexpected stage settings: %+v", opts)
	}
}

func TestDeduplicateAndProtocolFilter(t *testing.T) {
	nodes := []sub.Node{
		{Name: "A", Protocol: "vless", Key: "same"},
		{Name: "B", Protocol: "vless", Key: "same"},
		{Name: "C", Protocol: "ss", Key: "other"},
	}
	unique, duplicates := deduplicate(nodes)
	if duplicates != 1 || len(unique) != 2 {
		t.Fatalf("unique=%d duplicates=%d", len(unique), duplicates)
	}
	selected := filterProtocols(unique, []string{"ss"})
	if len(selected) != 1 || selected[0].Name != "C" {
		t.Fatalf("unexpected protocol selection: %#v", selected)
	}
}

func TestRunStageWaitsForEveryNodeAndCapsConcurrency(t *testing.T) {
	nodes := make([]sub.Node, 17)
	for i := range nodes {
		nodes[i].Name = "node"
	}
	var active, maxActive, completed atomic.Int32
	var out bytes.Buffer
	results := runStage(context.Background(), "TEST", nodes, 3, &out, func(n *sub.Node) bool { return n.URLPassed }, func(_ context.Context, n *sub.Node) {
		now := active.Add(1)
		for {
			old := maxActive.Load()
			if now <= old || maxActive.CompareAndSwap(old, now) {
				break
			}
		}
		time.Sleep(time.Millisecond)
		n.URLPassed = true
		completed.Add(1)
		active.Add(-1)
	})
	if completed.Load() != int32(len(nodes)) {
		t.Fatalf("completed=%d", completed.Load())
	}
	if maxActive.Load() > 3 {
		t.Fatalf("max concurrency=%d", maxActive.Load())
	}
	if len(results) != len(nodes) {
		t.Fatalf("results=%d", len(results))
	}
	for i, n := range results {
		if !n.URLPassed {
			t.Fatalf("node %d was not processed", i)
		}
	}
	if out.Len() == 0 {
		t.Fatal("expected progress output")
	}
}

func TestJSONStageFilesRoundTrip(t *testing.T) {
	dir := t.TempDir()
	nodes := []sub.Node{{Name: "test", Protocol: "ss", URI: "ss://example", URLPassed: true, Outbound: map[string]any{"type": "shadowsocks"}}}
	if err := writeStageFiles(dir, "url-test-finished", nodes, true); err != nil {
		t.Fatal(err)
	}
	got, err := readJSON(filepath.Join(dir, "url-test-finished.json"))
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 1 || got[0].Protocol != "ss" || !got[0].URLPassed {
		t.Fatalf("bad round trip: %#v", got)
	}
	var decoded []sub.Node
	data, err := os.ReadFile(filepath.Join(dir, "url-test-finished-ss.json"))
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(data, &decoded); err != nil || len(decoded) != 1 {
		t.Fatalf("protocol output invalid: %v %#v", err, decoded)
	}
}

func TestSpeedThresholdRequiresBothDirections(t *testing.T) {
	if got := speedThresholdError(12, 4.9, 5, 5); got == "" {
		t.Fatal("upload below threshold must fail")
	}
	if got := speedThresholdError(4.9, 12, 5, 5); got == "" {
		t.Fatal("download below threshold must fail")
	}
	if got := speedThresholdError(5, 5, 5, 5); got != "" {
		t.Fatalf("exact threshold should pass: %s", got)
	}
}

func TestCollectMetadataKeepsProfileHeadersOnlyOnce(t *testing.T) {
	sources := [][]byte{
		[]byte("#profile-title: Main\n#profile-web-page-url: https://example.net\n#announce: renewed\nvless://one"),
		[]byte("#profile-title: Main\n#support-url: https://example.net/help\nss://two"),
	}
	got := collectMetadata(sources)
	if len(got) != 4 {
		t.Fatalf("expected three unique metadata headers, got %#v", got)
	}
}
