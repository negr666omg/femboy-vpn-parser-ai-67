package sub

import "testing"

func TestParseURIProtocols(t *testing.T) {
	cases := []struct{ name, uri, typ string }{
		{"vless", "vless://11111111-1111-4111-8111-111111111111@example.com:443?type=ws&security=tls&sni=example.com&path=%2Fws#one", "vless"},
		{"trojan", "trojan://secret@example.com:443?sni=example.com#two", "trojan"},
		{"socks", "socks5://user:pass@example.com:1080#three", "socks"},
		{"http", "http://user:pass@example.com:8080#four", "http"},
		{"hysteria2", "hysteria2://secret@example.com:443?sni=example.com#five", "hysteria2"},
		{"tuic", "tuic://11111111-1111-4111-8111-111111111111:secret@example.com:443?sni=example.com#six", "tuic"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			n, err := ParseURI(tc.uri)
			if err != nil {
				t.Fatal(err)
			}
			if got := n.Outbound["type"]; got != tc.typ {
				t.Fatalf("type=%v want %s", got, tc.typ)
			}
			if n.Name == "" {
				t.Fatal("missing display name")
			}
		})
	}
}
func TestParseVMess(t *testing.T) {
	n, err := ParseURI("vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIsInBvcnQiOiI0NDMiLCJpZCI6IjExMTExMTExLTExMTEtNDExMS04MTExLTExMTExMTExMTExMSIsIm5ldCI6IndzIiwidGxzIjoidGxzIiwicHMiOiJ2bWVzcyJ9")
	if err != nil {
		t.Fatal(err)
	}
	if n.Outbound["type"] != "vmess" {
		t.Fatalf("unexpected type: %v", n.Outbound["type"])
	}
}
func TestDedupKeyIgnoresDisplayName(t *testing.T) {
	a, e := ParseURI("vless://11111111-1111-4111-8111-111111111111@example.com:443?security=tls#A")
	if e != nil {
		t.Fatal(e)
	}
	b, e := ParseURI("vless://11111111-1111-4111-8111-111111111111@example.com:443?security=tls#B")
	if e != nil {
		t.Fatal(e)
	}
	if a.Key != b.Key {
		t.Fatal("name changed dedup key")
	}
}

func TestParseShadowsocksURI(t *testing.T) {
	for _, uri := range []string{
		"ss://YWVzLTI1Ni1nY206cGFzcw@example.com:8388#ss-one",
		"ss://YWVzLTI1Ni1nY206cGFzc0BleGFtcGxlLmNvbTo4Mzg4#ss-two",
	} {
		n, err := ParseURI(uri)
		if err != nil {
			t.Fatalf("ParseURI(%q): %v", uri, err)
		}
		if n.Outbound["type"] != "shadowsocks" {
			t.Fatalf("unexpected outbound: %#v", n.Outbound)
		}
	}
}

func TestParseBase64Subscription(t *testing.T) {
	encoded := "dmxlc3M6Ly8xMTExMTExMS0xMTExLTQxMTEtODExMS0xMTExMTExMTExMTFAZXhhbXBsZS5jb206NDQzP3NlY3VyaXR5PXRscyNhbHBoYQp0cm9qYW46Ly9zZWNyZXRAZXhhbXBsZS5jb206NDQzI2JldGE="
	nodes, invalid, err := ParseDocument([]byte(encoded))
	if err != nil {
		t.Fatal(err)
	}
	if invalid != 0 || len(nodes) != 2 {
		t.Fatalf("nodes=%d invalid=%d", len(nodes), invalid)
	}
}
